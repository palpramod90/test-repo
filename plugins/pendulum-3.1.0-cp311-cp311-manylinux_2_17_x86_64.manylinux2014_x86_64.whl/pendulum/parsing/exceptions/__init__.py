from __future__ import annotations


class ParserError(ValueError):
    pass
